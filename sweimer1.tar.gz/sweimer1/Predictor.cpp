#include"Predictor.h"

using namespace std;

unsigned long long Predictor::alwaysTaken(string in, unsigned long long* tot) {
	unsigned long long numPredictions = 0;
	unsigned long long addr;
	string behavior, line;
	unsigned long long target;
	string prediction = "T";
	*tot = 0;

	ifstream infile(in);

	while(getline(infile, line)) {
		stringstream s(line);
		s >> std::hex >> addr >> behavior >> std::hex >> target;
		if(behavior == prediction) {
			numPredictions++;
		}
		(*tot)++;
	}

	//close files
	infile.close();

	return numPredictions;
}

unsigned long long Predictor::alwaysNotTaken(string in) {
	unsigned long long numPredictions = 0;
	unsigned long long addr;
	string behavior, line;
	unsigned long long target;
	string prediction = "NT";

	ifstream infile(in);

	while(getline(infile, line)) {
		stringstream s(line);
		s >> std::hex >> addr >> behavior >> std::hex >> target;
		if(behavior == prediction) {
			numPredictions++;
		}
	}

	//close files
	infile.close();

	return numPredictions;
}

unsigned long long Predictor::bimodalSingle(string in, int size) {
	unsigned long long numPredictions = 0;
	unsigned long long addr;
	string behavior, line;
	unsigned long long target;

	vector<string> table(size, "T");

	ifstream infile(in);

	while(getline(infile, line)) {
		stringstream s(line);
		s >> std::hex >> addr >> behavior >> std::hex >> target;
		int index = addr % size;
		if(table.at(index) == behavior) {
			numPredictions++;
		} else {
			table.at(index) = behavior;
		}
	}

	//close files
	infile.close();

	return numPredictions;
}

unsigned long long Predictor::bimodalDouble(string in, int size) {
	unsigned long long numPredictions = 0;
	unsigned long long addr;
	string behavior, line;
	unsigned long long target;

	vector<string> table(size, "TT");

	ifstream infile(in);

	while(getline(infile, line)) {
		stringstream s(line);
		s >> std::hex >> addr >> behavior >> std::hex >> target;
		int index = addr % size;
		if ((table.at(index) == "TT") && (behavior == "T")) {
			numPredictions++;
		} else if ((table.at(index) == "TNT") && (behavior == "T")) {
			numPredictions++;
			table.at(index) = "TT";
		} else if ((table.at(index) == "NTT") && (behavior == "NT")) {
			numPredictions++;
			table.at(index) = "NTNT";
		} else if ((table.at(index) == "NTNT") && (behavior == "NT")) {
			numPredictions++;
		} else if ((table.at(index) == "TT") && (behavior == "NT")) {
			table.at(index) = "TNT";
		} else if ((table.at(index) == "TNT") && (behavior == "NT")) {
			table.at(index) = "NTT";
		} else if ((table.at(index) == "NTT") && (behavior == "T")) {
			table.at(index) = "TNT";
		} else if ((table.at(index) == "NTNT") && (behavior == "T")) {
			table.at(index) = "NTT";
		}
	}

	//close files
	infile.close();

	return numPredictions;
}

unsigned long long Predictor::gshare(string in, int bits) {
	unsigned long long size = 2048;
	unsigned long long numPredictions = 0;
	unsigned long long addr;
	string behavior, line;
	unsigned long long target;
	unsigned long long GHR = 0;
	unsigned long long GHR_size = pow(2, bits);

	vector<string> table(size, "TT");

	ifstream infile(in);

	while(getline(infile, line)) {
		stringstream s(line);
		s >> std::hex >> addr >> behavior >> std::hex >> target;
		unsigned long long index = addr;
		GHR = GHR % GHR_size;
		index = index ^ GHR;
		index = index % size;
		if ((table.at(index) == "TT") && (behavior == "T")) {
			numPredictions++;
		} else if ((table.at(index) == "TNT") && (behavior == "T")) {
			numPredictions++;
			table.at(index) = "TT";
		} else if ((table.at(index) == "NTT") && (behavior == "NT")) {
			numPredictions++;
			table.at(index) = "NTNT";
		} else if ((table.at(index) == "NTNT") && (behavior == "NT")) {
			numPredictions++;
		} else if ((table.at(index) == "TT") && (behavior == "NT")) {
			table.at(index) = "TNT";
		} else if ((table.at(index) == "TNT") && (behavior == "NT")) {
			table.at(index) = "NTT";
		} else if ((table.at(index) == "NTT") && (behavior == "T")) {
			table.at(index) = "TNT";
		} else if ((table.at(index) == "NTNT") && (behavior == "T")) {
			table.at(index) = "NTT";
		}
		GHR = GHR << 1;
		if (behavior == "T") {
			GHR += 1;
		}
	}

	//close files
	infile.close();

	return numPredictions;
}

unsigned long long Predictor::tournament(string in) {
	unsigned long long size = 2048;
	unsigned long long numPredictions = 0;
	unsigned long long addr;
	string behavior, line;
	unsigned long long target;
	unsigned long long GHR = 0;
	unsigned long long GHR_size = pow(2, 11);
	unsigned long long selector;//selector index and bimodal index
	unsigned long long index;

	vector<string> gtable(size, "11");
	vector<string> btable(size, "11");
	vector<string> stable(size, "00");

	ifstream infile(in);

	while(getline(infile, line)) {
		stringstream s(line);
		s >> std::hex >> addr >> behavior >> std::hex >> target;
		index = addr % size;
		selector = addr % size;//should be 11 bits
		index = index ^ GHR;
		bool update_selector = true;
		bool gshare_right = false;
		bool bimodal_right = false;

		if (((gtable.at(index) == "11") || (gtable.at(index) == "10")) && ((btable.at(selector) == "11") || (btable.at(selector) == "10"))) {//both taken
			update_selector = false;
		}

		if (((gtable.at(index) == "01") || (gtable.at(index) == "00")) && ((btable.at(selector) == "01") || (btable.at(selector) == "00"))) {//both not taken
			update_selector = false;
		}

		if ((stable.at(selector) == "00") || (stable.at(selector) == "01")) {//if prefer or weakly prefer gshare
			if ((gtable.at(index) == "11") && (behavior == "T")) {
				gshare_right = true;
			} else if ((gtable.at(index) == "10") && (behavior == "T")) {
				gshare_right = true;
			} else if ((gtable.at(index) == "01") && (behavior == "NT")) {
				gshare_right = true;
			} else if ((gtable.at(index) == "00") && (behavior == "NT")) {
				gshare_right = true;
			}

			if (gshare_right) {
				numPredictions++;
			}

			if (update_selector) {//not both predictors had same result
				if (gshare_right) {//gshare was right
					if (stable.at(selector) == "01") {//if weakly prefer gshare
						stable.at(selector) = "00";//now strongly prefer gshare
					} else if (stable.at(selector) == "00") {//if strongly prefer gshare
						stable.at(selector) = "00";//still strongly prefer gshare
					}
				} else {//wrong
					if (stable.at(selector) == "01") {//if weakly prefer gshare
						stable.at(selector) = "10";//weakly prefer bimodal instead
					} else if (stable.at(selector) == "00") {//strongly prefer gshare
						stable.at(selector) = "01";//weakly prefer gshare
					}
				}
			}
		} else {//prefer or weakly prefer bimodal
			if ((btable.at(selector) == "11") && (behavior == "T")) {//bimodal right
				bimodal_right = true;
			} else if ((btable.at(selector) == "10") && (behavior == "T")) {//bimodal right
				bimodal_right = true;
			} else if ((btable.at(selector) == "01") && (behavior == "NT")) {//bimodal right
				bimodal_right = true;
			} else if ((btable.at(selector) == "00") && (behavior == "NT")) {//bimodal right
				bimodal_right = true;
			}

			if (bimodal_right) {
				numPredictions++;
			}

			if (update_selector) {//if both branches are not the same
				if (bimodal_right) {//if bimodal was right
					if (stable.at(selector) == "10") {//if weakly prefer bimodal
						stable.at(selector) = "11";//now strongly prefer bimodal
					} else if (stable.at(selector) == "11") {
						stable.at(selector) = "11";
					}
				} else {//if bimodal wrong
					if (stable.at(selector) == "10") {//if weakly prefer bimodal
						stable.at(selector) = "01";//now weakly prefer gshare
					} else if (stable.at(selector) == "11") {//if strongly prefer bimodal
						stable.at(selector) = "10";//weakly prefer bimodal
					}
				}
			}
		}

		if ((gtable.at(index) == "11") && (behavior == "NT")) {
			gtable.at(index) = "10";
		} else if ((gtable.at(index) == "10") && (behavior == "NT")) {
			gtable.at(index) = "01";
		} else if ((gtable.at(index) == "01") && (behavior == "T")) {
			gtable.at(index) = "10";
		} else if ((gtable.at(index) == "00") && (behavior == "T")) {
			gtable.at(index) = "01";
		} else if ((gtable.at(index) == "10") && (behavior == "T")) {
			gtable.at(index) = "11";
		} else if ((gtable.at(index) == "01") && (behavior == "NT")) {
			gtable.at(index) = "00";
		}

		if ((btable.at(selector) == "11") && (behavior == "NT")) {
			btable.at(selector) = "10";
		} else if ((btable.at(selector) == "10") && (behavior == "NT")) {
			btable.at(selector) = "01";
		} else if ((btable.at(selector) == "01") && (behavior == "T")) {
			btable.at(selector) = "10";
		} else if ((btable.at(selector) == "00") && (behavior == "T")) {
			btable.at(selector) = "01";
		} else if ((btable.at(selector) == "10") && (behavior == "T")) {//bimodal right
			btable.at(selector) = "11";
		} else if ((btable.at(selector) == "01") && (behavior == "NT")) {//bimodal right
			btable.at(selector) = "00";
		}
	
		GHR = GHR << 1;
		if (behavior == "T") {
			GHR += 1;
		}
		GHR = GHR % GHR_size;
	}

	//close files
	infile.close();

	return numPredictions;
}

unsigned long long Predictor::btb(string in, unsigned long long * numAttempts) {
	unsigned long long size = 512;
	unsigned long long numPredictions = 0;
	unsigned long long addr;
	string behavior, line;
	unsigned long long target;
	*numAttempts = 0;

	vector<unsigned long long> btbtable(size, 0);
	vector<string> sbtable(size, "T");

	ifstream infile(in);

	while(getline(infile, line)) {
		stringstream s(line);
		s >> std::hex >> addr >> behavior >> std::hex >> target;
		unsigned long long index = addr % size;

		if (sbtable.at(index) == "T") {//if bimodal predicts taken
			if (btbtable.at(index) == target) {//if btb table at index is the actual target
				numPredictions++;//correct predictions += 1
			}
			(*numAttempts)++;//estimated number of correct predictions
			if (behavior == "T") {//if actual behavior is taken
				btbtable.at(index) = target;//set btb table with actual target address
			} else {//if bimodal was wrong
				sbtable.at(index) = "NT";//update bimodal to not taken
			}
		} else {//if bimodal predicts not taken
			if (behavior == "T") {//but behavior is actually taken
				btbtable.at(index) = target;//set btb table with actual target address
				sbtable.at(index) = "T";//update bimodal to taken
			}
		}
	}

	//close files
	infile.close();

	return numPredictions;
}
