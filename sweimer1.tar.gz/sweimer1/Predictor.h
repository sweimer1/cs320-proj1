#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<vector>
#include<math.h>

using namespace std;

class Predictor {
	public:
		unsigned long long alwaysTaken(string in, unsigned long long* tot);
		unsigned long long alwaysNotTaken(string in);
		unsigned long long bimodalSingle(string in, int size);
		unsigned long long bimodalDouble(string in, int size);
		unsigned long long gshare(string in, int bits);
		unsigned long long tournament(string in);
		unsigned long long btb(string in, unsigned long long * numAttempts);
};
