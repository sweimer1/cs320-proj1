Samuel Weimer
sweimer1
B00719957
the whole thing works. just run "make" then: "./predictors <input_file.txt> <output_file.txt>"
