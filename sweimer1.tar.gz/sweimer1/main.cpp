#include"Predictor.h"

int main(int argc, char *argv[]) {

  unsigned long long* tot;
  tot = (unsigned long long*) malloc(sizeof(unsigned long long));
  unsigned long long* btbAttempts;
  btbAttempts = (unsigned long long*) malloc(sizeof(unsigned long long));

  ofstream output;
  output.open(argv[2]);

  Predictor p = Predictor();

  if (argc != 3) {
    cout << "Please run the program by typing:\n./predictors <input_file.txt> <output_file.txt>\n";
    exit(1);
  }

  output << p.alwaysTaken(argv[1], tot) << "," << *tot << ";" << endl;//Always Taken
  output << p.alwaysNotTaken(argv[1]) << "," << *tot << ";" << endl;//Always Not Taken

  output << p.bimodalSingle(argv[1], 16) << "," << *tot << "; ";//Bimodal Single
  output << p.bimodalSingle(argv[1], 32) << "," << *tot << "; ";
  output << p.bimodalSingle(argv[1], 128) << "," << *tot << "; ";
  output << p.bimodalSingle(argv[1], 256) << "," << *tot << "; ";
  output << p.bimodalSingle(argv[1], 512) << "," << *tot << "; ";
  output << p.bimodalSingle(argv[1], 1024) << "," << *tot << "; ";
  output << p.bimodalSingle(argv[1], 2048) << "," << *tot << ";" << endl;

  output << p.bimodalDouble(argv[1], 16) << "," << *tot << "; ";//Bimodal double
  output << p.bimodalDouble(argv[1], 32) << "," << *tot << "; ";
  output << p.bimodalDouble(argv[1], 128) << "," << *tot << "; ";
  output << p.bimodalDouble(argv[1], 256) << "," << *tot << "; ";
  output << p.bimodalDouble(argv[1], 512) << "," << *tot << "; ";
  output << p.bimodalDouble(argv[1], 1024) << "," << *tot << "; ";
  output << p.bimodalDouble(argv[1], 2048) << "," << *tot << ";" << endl;

  output << p.gshare(argv[1], 3) << "," << *tot << "; ";
  output << p.gshare(argv[1], 4) << "," << *tot << "; ";
  output << p.gshare(argv[1], 5) << "," << *tot << "; ";
  output << p.gshare(argv[1], 6) << "," << *tot << "; ";
  output << p.gshare(argv[1], 7) << "," << *tot << "; ";
  output << p.gshare(argv[1], 8) << "," << *tot << "; ";
  output << p.gshare(argv[1], 9) << "," << *tot << "; ";
  output << p.gshare(argv[1], 10) << "," << *tot << "; ";
  output << p.gshare(argv[1], 11) << "," << *tot << ";" << endl;

  output << p.tournament(argv[1]) << "," << *tot << ";" << endl;

  output << p.btb(argv[1], btbAttempts) << "," << *btbAttempts << ";" << endl;

  free(tot);
  output.close();

  return 0;
}
